/* Isaac St Hubert 01/18/2026 Module 1.3
   This program calculates the Joules needed from user input */

import java.util.Scanner;

public class CalculateEnergy {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Prompt user for inputs
        System.out.println("Enter the amount of water in kilograms: ");
        double waterMass = input.nextDouble();

        System.out.println("Enter the initial temperature in Celsius: ");
        double initialTemperature = input.nextDouble();

        System.out.println("Enter the final temperature in Celsius: ");
        double finalTemperature = input.nextDouble();

        // Calculate energy
        double Q = waterMass * (finalTemperature - initialTemperature) * 4184;


        System.out.println("The energy needed is " + Q + " Joules.");

        input.close();
    }
}
